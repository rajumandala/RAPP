﻿Imports System.IO 'File Input & Output
Imports System.Xml.Serialization 'The Serialization namespace contains classes that are used to serialize objects into XML format documents or streams

Public Class frmSD

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Application.Exit()

    End Sub

    Private Sub btnS_Click(sender As Object, e As EventArgs) Handles btnS.Click

        'Instantiate new Student object
        Dim stu As New clsStudent()

        'Information to save
        stu.StudentName = txtName.Text
        stu.StudentCourse = txtCourse.Text
        stu.StudentNumber = Convert.ToInt16(txtStuNum.Text)

        'Serialize student object to an XML file, via the use of StreamWriter
        Dim objStreamWriter As New StreamWriter("C:\StudentInfo.xml")

        Dim xsSerialize As New XmlSerializer(stu.GetType) 'Determine what object types are present

        xsSerialize.Serialize(objStreamWriter, stu) 'Save

        objStreamWriter.Close() 'Close File

    End Sub

    Private Sub btnD_Click(sender As Object, e As EventArgs) Handles btnD.Click

        'Deserialize XML file to a new Student object.
        Dim objStreamReader As New StreamReader("C:\StudentInfo.xml") 'Read File

        Dim stu As New clsStudent() 'Instantiate new Student Object

        Dim xsDeserialize As New XmlSerializer(stu.GetType) 'Get Info present

        stu = xsDeserialize.Deserialize(objStreamReader) 'Deserialize / Open

        objStreamReader.Close() 'Close Reader

        'Display values of the new student object
        txtName.Text = stu.StudentName
        txtCourse.Text = stu.StudentCourse
        txtStuNum.Text = CStr(stu.StudentNumber)

    End Sub
End Class
