﻿Imports System.Xml.Serialization 'The Serialization namespace contains classes that are used to serialize objects into XML format documents or streams

Public Class clsStudent

    Private strName As String 'Name Member Variable
    Private strCourse As String 'Course Member Variable
    Private intStuNo As Integer 'StudentNumber Member Variable

    'Gets / Sets Student Name
    Public Property StudentName() As String

        Get

            StudentName = strName

        End Get

        Set(ByVal Value As String)

            strName = Value

        End Set

    End Property

    'Gets / Sets Student's Course
    Public Property StudentCourse() As String

        Get

            StudentCourse = strCourse

        End Get

        Set(ByVal Value As String)

            strCourse = Value

        End Set

    End Property

    'Gets / Sets StudentNumber
    <XmlElementAttribute(ElementName:="Student Number")> _
    Public Property StudentNumber() As Integer

        Get

            StudentNumber = intStuNo

        End Get

        Set(ByVal Value As Integer)

            intStuNo = Value

        End Set

    End Property

End Class
