---
layout: default
---
# StubExample class
---
## Properties

### `greeting` → `String`

### `isTrue` → `Boolean`

### `notMocked` → `Boolean`

---
## Methods
### `getGreeting()` → `String`
### `getIsTrue()` → `Boolean`
### `setGreeting(String greeting)` → `void`
### `setGreeting(Integer greeting)` → `void`
---
