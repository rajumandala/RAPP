---
layout: default
---
# Feature class

Class is responsible for helping determine if specific platform features are enabled in the current org

---
## Methods
### `platformCache()` → `Boolean`
---
